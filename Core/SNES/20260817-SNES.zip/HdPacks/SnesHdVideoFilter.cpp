#include "pch.h"
#include <vector>
#include "SNES/HdPacks/SnesHdVideoFilter.h"
#include "SNES/HdPacks/SnesHdPackLoader.h"
#include "SNES/SnesConsole.h"
#include "SNES/SnesPpu.h"
#include "Shared/Emulator.h"
#include "Shared/MessageManager.h"

#include "Shared/pl_mpeg.h"
#include "Utilities/FolderUtilities.h"
#include "Shared/Audio/SoundMixer.h"


//-----------------------------------------------------------------------------------------
SnesHdVideoFilter::SnesHdVideoFilter(Emulator* emu) : SnesDefaultVideoFilter(emu) {}


//----------------------------------------------------------------------------------------

FrameInfo SnesHdVideoFilter::GetFrameInfo()
{
	static bool frameLog = false;
	if(!frameLog) {
		MessageManager::Log("[HD TRACE 2.5] GetFrameInfo a pris le relais pour l'affichage !");
		frameLog = true;
	}

	_sdFrameInfo = SnesDefaultVideoFilter::GetFrameInfo();
	FrameInfo info = _sdFrameInfo;

	// On agrandit la fenêtre en fonction de l'échelle du pack
	if(SnesHdPackLoader::ActivePack) {
		uint32_t scale = SnesHdPackLoader::ActivePack->Scale;
		info.Width *= scale;
		info.Height *= scale;

	}
	return info;
}
//-------------------------------------------------------------------------

// ============================================================================
// IMPLEMENTATION DE LA REGLE DE Z-INDEX
// ============================================================================
bool SnesHdLayerOrderRule::MatchesCondition(int x, int y, SnesHdPixelData* tile)
{
	for(auto cond : Conditions) {
		if(!cond->CheckCondition(x, y, tile)) {
			return false;
		}
	}
	return true;
}

//---------------------------------------------------------------------------------------------------------------
void SnesHdVideoFilter::ApplyFilter(uint16_t* ppuOutputBuffer)
{
	static bool filterLog = false;

	/*
	// La structure pour mémoriser les sprites HD tronqués à "déplier"
	struct ExpandedSprite
	{
		SnesHdPackTileInfo* Tile;
		int startX;
		int startY;
		uint8_t zIndex;
		bool hFlip;
		bool vFlip;
		uint16_t baseColor;
	};
	std::vector<ExpandedSprite> spritesToExpand;
	*/

	// La structure pour mémoriser TOUTES les tuiles HD tronquées à "déplier"
	struct ExpandedTile
	{
		SnesHdPackTileInfo* Tile;
		int startX;
		int startY;
		uint8_t zIndex;
		bool hFlip;
		bool vFlip;
		uint16_t baseColor;
	};
	std::vector<ExpandedTile> tilesToExpand;


	// Si pas de pack HD, on utilise le filtre classique
	if(!SnesHdPackLoader::ActivePack) {
		SnesDefaultVideoFilter::ApplyFilter(ppuOutputBuffer);
		return;
	}

	uint32_t scale = SnesHdPackLoader::ActivePack->Scale;
	uint32_t* out = GetOutputBuffer(); // Le tableau de la grande image finale

	uint32_t sdWidth = _sdFrameInfo.Width;
	uint32_t sdHeight = _sdFrameInfo.Height;
	OverscanDimensions overscan = GetOverscan();

	uint32_t xOffset = overscan.Left;
	uint32_t yOffset = overscan.Top * _baseFrameInfo.Width;


	// On récupère notre grand écran HD caché généré par le PPU !
	SnesConsole* console = (SnesConsole*)_emu->GetConsole().get();
	SnesHdPixelData* hdBuffer = console->GetPpu()->GetHdScreenBuffer();
	SnesHdPixelData* hdSubBuffer = console->GetPpu()->GetHdSubScreenOutputBuffer();

	// ====================================================================
	// DÉCLARATIONS HD ET INITIALISATION DU Z-BUFFER (CORRIGÉ)
	// ====================================================================
	uint32_t outWidth = sdWidth * scale;  // Largeur totale de l'écran HD final
	uint32_t hdHeight = sdHeight * scale; // <-- On a remonté hdHeight ici !

	if(_zBuffer.size() != outWidth * hdHeight) {
		_zBuffer.resize(outWidth * hdHeight);
	}
	memset(_zBuffer.data(), 0, _zBuffer.size()); // On efface le Z-Buffer pour cette nouvelle frame
	// ====================================================================
	for(uint32_t y = 0; y < sdHeight; y++) {

		// ====================================================================
		// ÉTAPE 1 : PRE-PASS MODE 7 (On déroule le sol SOUS les sprites)
		// ====================================================================
		bool hasMode7OnLine = false;
		SnesHdPixelData refM7Data;
		uint32_t refX = 0;
		uint16_t lineSnesPixel = 0;

		// On scanne la ligne pour attraper le PREMIER pixel Mode 7 visible
		for(uint32_t tx = 0; tx < sdWidth; tx++) {
			uint32_t offset = y * _baseFrameInfo.Width + tx + yOffset + xOffset;
			if(hdBuffer[offset].IsMode7) {
				refM7Data = hdBuffer[offset];
				lineSnesPixel = ppuOutputBuffer[offset];
				refX = tx; // On mémorise OÙ on a trouvé ce pixel
				hasMode7OnLine = true;
				break;
			}
		}

		if(hasMode7OnLine) {
			// On dessine le Mode 7 sur TOUTE la largeur de l'écran, sans trou !
			for(uint32_t x = 0; x < sdWidth; x++) {

				// ============================================================
				// LA CORRECTION EST ICI : L'EXTRAPOLATION DE LA MATRICE !
				// ============================================================
				SnesHdPixelData lineM7Data = refM7Data;

				// On calcule la distance entre le pixel actuel (x) et notre pixel de référence (refX)
				int32_t xDiff = (int32_t)x - (int32_t)refX;

				// On avance la texture proportionnellement à cette distance !
				// (M7A = Vitesse de défilement horizontal, M7C = Vitesse de défilement vertical)
				lineM7Data.M7XValue = refM7Data.M7XValue + (refM7Data.M7A * xDiff);
				lineM7Data.M7YValue = refM7Data.M7YValue + (refM7Data.M7C * xDiff);
				// ============================================================

				// --- Calcul de la profondeur (Z-Index) pour le fond Mode 7 ---
				uint8_t pixelZ = 20 + (lineM7Data.SnesPriorityLevel * 4);
				if(lineM7Data.IsHighPriority) pixelZ += 2;

				if(lineM7Data.SourceLayer >= 0 && lineM7Data.SourceLayer < 4) {
					for(auto& rule : SnesHdPackLoader::ActivePack->LayerOrders) {
						if(rule.MatchesCondition(x, y, &lineM7Data)) {
							pixelZ = rule.ZIndexBg[lineM7Data.SourceLayer];
							if(lineM7Data.IsHighPriority) pixelZ += 2;
							break;
						}
					}
				}

				// ============================================================
				// CORRECTION DU CODE-BARRES : On lit le VRAI pixel natif pour chaque X !
				// ============================================================
				uint32_t currentOffset = y * _baseFrameInfo.Width + x + yOffset + xOffset;
				uint16_t currentSnesPixel = ppuOutputBuffer[currentOffset];

				uint32_t sdColor = SnesHdPackLoader::ActivePack->IsColorMathDisabled
					? _calculatedPalette[lineM7Data.BaseColor]
					: _calculatedPalette[currentSnesPixel];

				// --- LA VOIE RAPIDE (FAST PATH) MODE 7 GÉANT ---
				SnesHdMode7Image* m7Img = SnesHdPackLoader::ActivePack->GetMode7Image(lineM7Data.M7MapHash);

				if(m7Img && m7Img->Bitmap && !m7Img->Bitmap->PixelData.empty()) {
					uint32_t outScale = scale;
					uint32_t imgScale = m7Img->Scale;
					uint32_t mapDim = 1024 * imgScale;

					if(m7Img->Mipmaps.empty()) {
						m7Img->Mipmaps.push_back(m7Img->Bitmap->PixelData);
						uint32_t currentDim = mapDim;
						for(int level = 1; level <= 3; level++) {
							uint32_t prevDim = currentDim;
							currentDim /= 2;
							std::vector<uint32_t> nextMip(currentDim * currentDim, 0);
							const std::vector<uint32_t>& prevMip = m7Img->Mipmaps[level - 1];

							for(uint32_t my = 0; my < currentDim; my++) {
								for(uint32_t mx = 0; mx < currentDim; mx++) {
									uint32_t p00 = prevMip[(my * 2) * prevDim + (mx * 2)];
									uint32_t p10 = prevMip[(my * 2) * prevDim + (mx * 2 + 1)];
									uint32_t p01 = prevMip[(my * 2 + 1) * prevDim + (mx * 2)];
									uint32_t p11 = prevMip[(my * 2 + 1) * prevDim + (mx * 2 + 1)];

									uint32_t a1 = p00 >> 24, a2 = p10 >> 24, a3 = p01 >> 24, a4 = p11 >> 24;
									uint32_t sumA = a1 + a2 + a3 + a4;

									if(sumA == 0) {
										nextMip[my * currentDim + mx] = 0x00000000;
									} else {
										uint32_t r = (((p00 >> 16) & 0xFF) * a1 + ((p10 >> 16) & 0xFF) * a2 + ((p01 >> 16) & 0xFF) * a3 + ((p11 >> 16) & 0xFF) * a4) / sumA;
										uint32_t g = (((p00 >> 8) & 0xFF) * a1 + ((p10 >> 8) & 0xFF) * a2 + ((p01 >> 8) & 0xFF) * a3 + ((p11 >> 8) & 0xFF) * a4) / sumA;
										uint32_t b = ((p00 & 0xFF) * a1 + (p10 & 0xFF) * a2 + (p01 & 0xFF) * a3 + (p11 & 0xFF) * a4) / sumA;
										nextMip[my * currentDim + mx] = ((sumA / 4) << 24) | (r << 16) | (g << 8) | b;
									}
								}
							}
							m7Img->Mipmaps.push_back(nextMip);
						}
					}

					bool applyColorMath = !m7Img->IgnoreColorMath;
					int diffR = 0, diffG = 0, diffB = 0;

					if(applyColorMath) {
						uint32_t baseSdColor = _calculatedPalette[lineM7Data.BaseColor];
						diffR = ((sdColor >> 16) & 0xFF) - ((baseSdColor >> 16) & 0xFF);
						diffG = ((sdColor >> 8) & 0xFF) - ((baseSdColor >> 8) & 0xFF);
						diffB = (sdColor & 0xFF) - (baseSdColor & 0xFF);
					}

					int32_t baseHD_X = lineM7Data.M7XValue * imgScale;
					int32_t baseHD_Y = lineM7Data.M7YValue * imgScale;
					int32_t stepX = (lineM7Data.M7A * (int32_t)imgScale) / (int32_t)outScale;
					int32_t stepY = (lineM7Data.M7C * (int32_t)imgScale) / (int32_t)outScale;

					int64_t stepDistSq = ((int64_t)stepX * stepX + (int64_t)stepY * stepY) >> 16;
					int lod = 0;
					if(stepDistSq > 16) lod = 3;
					else if(stepDistSq > 4) lod = 2;
					else if(stepDistSq > 1) lod = 1;
					if(lod >= m7Img->Mipmaps.size()) lod = m7Img->Mipmaps.size() - 1;

					uint32_t currentMapDim = mapDim >> lod;
					uint32_t currentBitMask = currentMapDim - 1;
					const uint32_t* currentPixelData = m7Img->Mipmaps[lod].data();

					for(uint32_t sy = 0; sy < outScale; sy++) {
						int32_t cur_BaseX = baseHD_X + (lineM7Data.M7B * (int32_t)imgScale * (int32_t)sy) / (int32_t)outScale;
						int32_t cur_BaseY = baseHD_Y + (lineM7Data.M7D * (int32_t)imgScale * (int32_t)sy) / (int32_t)outScale;
						uint32_t outBaseIdx = (y * outScale + sy) * outWidth + (x * outScale);

						for(uint32_t sx = 0; sx < outScale; sx++) {
							int32_t exactX = cur_BaseX + stepX * (int32_t)sx;
							int32_t exactY = cur_BaseY + stepY * (int32_t)sx;
							int32_t lodExactX = exactX >> lod;
							int32_t lodExactY = exactY >> lod;
							int32_t pngX = lodExactX >> 8;
							int32_t pngY = lodExactY >> 8;

							uint32_t finalColor = sdColor;

							if(!(lineM7Data.M7LargeMap && (pngX < 0 || pngX >= (int32_t)currentMapDim || pngY < 0 || pngY >= (int32_t)currentMapDim))) {
								uint32_t hdColorFromPng = 0;

								if(m7Img->UseBilinearFilter) {
									uint32_t fracX = lodExactX & 0xFF;
									uint32_t fracY = lodExactY & 0xFF;
									uint32_t x0 = pngX & currentBitMask;
									uint32_t x1 = (pngX + 1) & currentBitMask;
									uint32_t y0 = pngY & currentBitMask;
									uint32_t y1 = (pngY + 1) & currentBitMask;

									uint32_t p00 = currentPixelData[y0 * currentMapDim + x0];
									uint32_t p10 = currentPixelData[y0 * currentMapDim + x1];
									uint32_t p01 = currentPixelData[y1 * currentMapDim + x0];
									uint32_t p11 = currentPixelData[y1 * currentMapDim + x1];

									uint32_t w00 = ((256 - fracX) * (256 - fracY)) >> 8;
									uint32_t w10 = (fracX * (256 - fracY)) >> 8;
									uint32_t w01 = ((256 - fracX) * fracY) >> 8;
									uint32_t w11 = (fracX * fracY) >> 8;
									uint32_t a = (((p00 >> 24) & 0xFF) * w00 + ((p10 >> 24) & 0xFF) * w10 + ((p01 >> 24) & 0xFF) * w01 + ((p11 >> 24) & 0xFF) * w11) >> 8;

									if(a > 0) {
										uint32_t r = (((p00 >> 16) & 0xFF) * w00 + ((p10 >> 16) & 0xFF) * w10 + ((p01 >> 16) & 0xFF) * w01 + ((p11 >> 16) & 0xFF) * w11) >> 8;
										uint32_t g = (((p00 >> 8) & 0xFF) * w00 + ((p10 >> 8) & 0xFF) * w10 + ((p01 >> 8) & 0xFF) * w01 + ((p11 >> 8) & 0xFF) * w11) >> 8;
										uint32_t b = ((p00 & 0xFF) * w00 + (p10 & 0xFF) * w10 + (p01 & 0xFF) * w01 + (p11 & 0xFF) * w11) >> 8;
										hdColorFromPng = (a << 24) | (r << 16) | (g << 8) | b;
									} else {
										hdColorFromPng = 0x00000000;
									}
								} else {
									pngX &= currentBitMask;
									pngY &= currentBitMask;
									hdColorFromPng = currentPixelData[pngY * currentMapDim + pngX];
								}

								if((hdColorFromPng >> 24) > 0) {
									if(applyColorMath) {
										int outR = ((hdColorFromPng >> 16) & 0xFF) + diffR;
										int outG = ((hdColorFromPng >> 8) & 0xFF) + diffG;
										int outB = (hdColorFromPng & 0xFF) + diffB;

										outR = outR < 0 ? 0 : (outR > 255 ? 255 : outR);
										outG = outG < 0 ? 0 : (outG > 255 ? 255 : outG);
										outB = outB < 0 ? 0 : (outB > 255 ? 255 : outB);

										finalColor = (hdColorFromPng & 0xFF000000) | (outR << 16) | (outG << 8) | outB;
									} else {
										finalColor = hdColorFromPng | 0xFF000000;
									}

								} else {
									// CORRECTION METROID : Si la texture HD a un trou transparent, 
									// on efface la texture SNES originale pour laisser le vide !
									finalColor = 0x00000000;

									/*
									if(SnesHdPackLoader::ActivePack->DisableOriginalTiles) {
										finalColor = 0x00000000;
									} else {
										finalColor = sdColor;
									}
									*/


								}
							}

							out[outBaseIdx + sx] = finalColor;
							_zBuffer[outBaseIdx + sx] = ((finalColor >> 24) == 0) ? 0 : pixelZ;
						}
					}
				}
			}
		}

		// ====================================================================
		// ÉTAPE 2 : LA BOUCLE CLASSIQUE (Sprites et Tuiles)
		// ====================================================================
		for(uint32_t x = 0; x < sdWidth; x++) {

			uint32_t bufferOffset = y * _baseFrameInfo.Width + x + yOffset + xOffset;
			uint16_t snesPixel = ppuOutputBuffer[bufferOffset];

			SnesHdPixelData hdDataMain = hdBuffer[bufferOffset];
			SnesHdPixelData hdDataSub = hdSubBuffer[bufferOffset];
			SnesHdPixelData hdData = hdDataMain;

			bool hasSubScreenHdElement = (hdDataSub.Tile != nullptr && !hdDataSub.Tile->HdTileData.empty());
			if(hasSubScreenHdElement) {
				hdData = hdDataSub;
			}

			// ====================================================================
			// NOUVEAU : COURT-CIRCUIT DU MODE 7 !
			// Si le pixel d'origine est du Mode 7 géant, on le saute : le Pre-Pass 
			// l'a déjà dessiné juste au-dessus.
			// ====================================================================
			if(hdData.IsMode7) {
				continue;
			}

			uint32_t sdColor = SnesHdPackLoader::ActivePack->IsColorMathDisabled
				? _calculatedPalette[hdData.BaseColor]
				: _calculatedPalette[snesPixel];

			uint8_t pixelZ = 20 + (hdData.SnesPriorityLevel * 4);
			if(hdData.IsHighPriority) {
				pixelZ += 2;
			}

			if(!hdData.IsSprite && hdData.SourceLayer >= 0 && hdData.SourceLayer < 4) {
				for(auto& rule : SnesHdPackLoader::ActivePack->LayerOrders) {
					if(!rule.MatchesCondition(x, y, &hdData)) {
						continue;
					}
					pixelZ = rule.ZIndexBg[hdData.SourceLayer];
					if(hdData.IsHighPriority) {
						pixelZ += 2;
					}
					break;
				}
			}

			// ======
			// LA VOIE RAPIDE N°2 : TUILES MODE 7 INDIVIDUELLES (CLIPPÉES)
			// ===
			if(hdData.IsMode7Tile) {
				SnesHdMode7Image* m7Img = SnesHdPackLoader::ActivePack->GetMode7Image(hdData.M7TileHash);

				if(m7Img && m7Img->Bitmap && !m7Img->Bitmap->PixelData.empty()) {
					const uint32_t* rawPixelData = m7Img->Bitmap->PixelData.data();

					uint32_t imgScale = m7Img->Scale;
					int32_t tileDim = 8 * imgScale;

					uint32_t pngWidth = m7Img->Bitmap->Width;
					uint32_t pngHeight = m7Img->Bitmap->Height;
					int32_t srcX = m7Img->X;
					int32_t srcY = m7Img->Y;

					uint32_t mapDim = 1024 * imgScale;
					uint32_t bitMask = mapDim - 1;

					uint32_t baseSdColor = _calculatedPalette[hdData.BaseColor];
					int diffR = ((sdColor >> 16) & 0xFF) - ((baseSdColor >> 16) & 0xFF);
					int diffG = ((sdColor >> 8) & 0xFF) - ((baseSdColor >> 8) & 0xFF);
					int diffB = (sdColor & 0xFF) - (baseSdColor & 0xFF);

					int32_t baseHD_X = hdData.M7XValue * imgScale;
					int32_t baseHD_Y = hdData.M7YValue * imgScale;

					int32_t snesX = (hdData.M7XValue >> 8) & 1023;
					int32_t snesY = (hdData.M7YValue >> 8) & 1023;
					int32_t tileMinX = (snesX & ~7) * imgScale;
					int32_t tileMinY = (snesY & ~7) * imgScale;

					int32_t stepX = (hdData.M7A * (int32_t)imgScale) / (int32_t)scale;
					int32_t stepY = (hdData.M7C * (int32_t)imgScale) / (int32_t)scale;
					int32_t stepYTermX = (hdData.M7B * (int32_t)imgScale) / (int32_t)scale;
					int32_t stepYTermY = (hdData.M7D * (int32_t)imgScale) / (int32_t)scale;

					for(uint32_t sy = 0; sy < scale; sy++) {

						int32_t yTermX = stepYTermX * (int32_t)sy;
						int32_t yTermY = stepYTermY * (int32_t)sy;

						uint32_t outBaseIdx = (y * scale + sy) * outWidth + (x * scale);

						for(uint32_t sx = 0; sx < scale; sx++) {

							int32_t pngX = (baseHD_X + stepX * (int32_t)sx + yTermX) >> 8;
							int32_t pngY = (baseHD_Y + stepY * (int32_t)sx + yTermY) >> 8;

							pngX &= bitMask;
							pngY &= bitMask;

							int32_t localX = (pngX - tileMinX) & bitMask;
							int32_t localY = (pngY - tileMinY) & bitMask;

							// Clamp de sécurité absolu dans la limite de la tuile HD
							if(localX > (int32_t)(bitMask >> 1)) localX = 0;
							else if(localX >= tileDim) localX = tileDim - 1;

							if(localY > (int32_t)(bitMask >> 1)) localY = 0;
							else if(localY >= tileDim) localY = tileDim - 1;

							// Coordonnées de lecture finales dans l'atlas PNG
							uint32_t finalReadX = srcX + localX;
							uint32_t finalReadY = srcY + localY;

							// Si le PNG est trop petit (ou mal configuré dans hires.txt), on évite le crash et on ignore.
							if(finalReadX < pngWidth && finalReadY < pngHeight) {

								uint32_t hdColorFromPng = rawPixelData[finalReadY * pngWidth + finalReadX];

								// L'Alpha test : on ne dessine que les pixels opaques de la tuile
								if((hdColorFromPng >> 24) > 0) {
									int outR = ((hdColorFromPng >> 16) & 0xFF) + diffR;
									int outG = ((hdColorFromPng >> 8) & 0xFF) + diffG;
									int outB = (hdColorFromPng & 0xFF) + diffB;

									outR = outR < 0 ? 0 : (outR > 255 ? 255 : outR);
									outG = outG < 0 ? 0 : (outG > 255 ? 255 : outG);
									outB = outB < 0 ? 0 : (outB > 255 ? 255 : outB);

									uint32_t finalColor = (hdColorFromPng & 0xFF000000) | (outR << 16) | (outG << 8) | outB;

									out[outBaseIdx + sx] = finalColor;
									_zBuffer[outBaseIdx + sx] = pixelZ;
								}
							}
						}
					}
				}
				continue; // La tuile Mode 7 a été interceptée et rendue, on skip la voie classique.
			}



			// ====================================================================
			// LA CAPTURE UNIVERSELLE (SPRITES ET BACKGROUNDS)
			// On mémorise la position d'origine de TOUTE tuile ayant un PNG HD !
			// ====================================================================
			if(hdData.Tile != nullptr && !hdData.Tile->HdTileData.empty()) {

				// CORRECTION DU BÉGAIEMENT : Calcul de la position VISUELLE (0 à 7) à l'écran
				int visualX = 0;
				if(hdData.IsSprite) {
					// Pour les Sprites : TileX va de 0 à 7 normalement
					visualX = hdData.HFlip ? (7 - hdData.TileX) : hdData.TileX;
				} else {
					// Pour les Backgrounds : TileX va de 7 à 0 normalement
					visualX = hdData.HFlip ? hdData.TileX : (7 - hdData.TileX);
				}

				// VFlip se comporte de la même manière pour les BGs et les Sprites
				int visualY = hdData.VFlip ? (7 - hdData.TileY) : hdData.TileY;

				// Le point de départ absolu de l'image PNG
				int startX = (int)x - visualX;
				int startY = (int)y - visualY;

				bool alreadyCaptured = false;
				// OPTIMISATION : On lit la liste à l'envers pour trouver immédiatement le doublon
				for(int i = (int)tilesToExpand.size() - 1; i >= 0; i--) {
					if(tilesToExpand[i].Tile == hdData.Tile && tilesToExpand[i].startX == startX && tilesToExpand[i].startY == startY) {
						alreadyCaptured = true;
						break;
					}
				}

				if(!alreadyCaptured) {
					tilesToExpand.push_back({ hdData.Tile, startX, startY, pixelZ, hdData.HFlip, hdData.VFlip, hdData.BaseColor });
				}
			}

			// ===============================================
			// LA VOIE CLASSIQUE : ON APPELLE LE STANDARD POUR TOUT LE MONDE !
			// ===============================================
			//ApplyFilterSpritesStandard(x, y, scale, outWidth, sdColor, hdData, pixelZ, out);

			// --- DÉBUT DE LA CORRECTION ---
			bool hasHdReplacement = (hdData.Tile != nullptr && !hdData.Tile->HdTileData.empty());
			bool hideNative = hasHdReplacement;

			// On vérifie si l'utilisateur a globalement désactivé les tuiles ou sprites originaux via le pack
			if(hdData.IsSprite && SnesHdPackLoader::ActivePack->DisableOriginalSprites) {
				hideNative = true;
			} else if(!hdData.IsSprite && SnesHdPackLoader::ActivePack->DisableOriginalTiles) {
				hideNative = true;
			}

			// CORRECTION BUG MARIO KART (Ombres noires sur le Mode 7) :
			// Si l'élément natif doit être caché et qu'on est sur une ligne contenant du Mode 7,
			// on passe au pixel suivant pour ne pas écraser le fond Mode 7 généré à l'étape 1 avec du noir.
			if(hasMode7OnLine && hideNative) {
				continue;
			}
			// --- FIN DE LA CORRECTION ---

			ApplyFilterSpritesStandard(x, y, scale, outWidth, sdColor, hdData, pixelZ, out);

		}
	}
	// ====================================================================
		// LE DÉPLIAGE UNIVERSEL (SCREEN-SPACE EXPANSION)
		// On dessine l'intégralité du PNG pour vaincre le clipping (Sprites et BGs)
		// ====================================================================
	for(auto& item : tilesToExpand) {
		uint32_t pngWidth = item.Tile->Width * scale;
		uint32_t pngHeight = item.Tile->Height * scale;

		bool doHFlip = item.hFlip && !item.Tile->IsHFlip;
		bool doVFlip = item.vFlip && !item.Tile->IsVFlip;

		for(uint32_t py = 0; py < pngHeight; py++) {
			for(uint32_t px = 0; px < pngWidth; px++) {

				int32_t screenX = (item.startX * scale) + px;
				int32_t screenY = (item.startY * scale) + py;

				// Sécurité pour ne pas dessiner hors de l'écran
				if(screenX < 0 || screenX >= (int32_t)outWidth || screenY < 0 || screenY >= (int32_t)hdHeight) continue;

				uint32_t readX = doHFlip ? (pngWidth - 1 - px) : px;
				uint32_t readY = doVFlip ? (pngHeight - 1 - py) : py;

				uint32_t hdColorFromPng = item.Tile->HdTileData[readY * pngWidth + readX];
				uint32_t alpha = (hdColorFromPng >> 24) & 0xFF;

				if(alpha > 0) {
					uint32_t pixelIndex = screenY * outWidth + screenX;

					// === LE Z-TEST MAGIQUE ===
					if(item.zIndex >= _zBuffer[pixelIndex]) {

						uint32_t finalColor = hdColorFromPng;

						if(!(SnesHdPackLoader::ActivePack->IsColorMathDisabled || item.Tile->IgnoreColorMath)) {
							// Tu peux remettre le calcul de ColorMath ici si nécessaire
						}

						out[pixelIndex] = finalColor | 0xFF000000;
						_zBuffer[pixelIndex] = item.zIndex;
					}
				}
			}
		}
	}


	// =======================================================
	// RENDU DES BACKGROUNDS HD (TAG <background>) AVEC PARALLAXE
	// =======================================================
	uint32_t hdWidth = outWidth; // On crée l'alias pour que le code du dessous fonctionne !

	for(auto& bg : SnesHdPackLoader::ActivePack->Backgrounds) {

		// Vérification de la condition
		if(!bg->MatchesCondition()) continue;
		// ==========================================================
		// MISE À JOUR DE L'ANIMATION DU BACKGROUND
		// ==========================================================
		if(bg->IsAnimated && !bg->AnimFrames.empty() && bg->FramesBetweenSteps > 0) {
			uint32_t currentFrame = SnesHdPackLoader::ActivePack->ScreenInfo.FrameNumber;
			int totalFrames = (int)bg->AnimFrames.size();
			int currentAnimIndex = (currentFrame / bg->FramesBetweenSteps) % totalFrames;

			bg->Bitmap = bg->AnimFrames[currentAnimIndex];
		}
		// ==========================================================
		if(bg->Bitmap == nullptr) continue; // Sécurité


		// Lazy Loading sécurisé
		bg->Bitmap->Init();
		if(bg->Bitmap->PixelData.empty() || bg->Bitmap->Width == 0 || bg->Bitmap->Height == 0) continue;

		int bgWidth = bg->Bitmap->Width;
		int bgHeight = bg->Bitmap->Height;
		int bgIndex = bg->MasterScrollLayer - 1;

		// ON DESSINE L'IMAGE SUR TOUTE LA TAILLE DE L'ÉCRAN HD
		for(uint32_t hdY = 0; hdY < hdHeight; hdY++) {

			// 1. On trouve la ligne de base de la SNES (0 à 239)
			uint32_t sdY = hdY / scale;

			// 2. VOYAGE DANS LE TEMPS : On lit l'historique du scroll pour CETTE ligne !
			int masterScrollX = 0;
			int masterScrollY = 0;

			if(bgIndex >= 0 && bgIndex < 4 && sdY < 240) {
				auto& screenInfo = SnesHdPackLoader::ActivePack->ScreenInfo;
				masterScrollX = screenInfo.ScanlineHScroll[sdY][bgIndex];
				masterScrollY = screenInfo.ScanlineVScroll[sdY][bgIndex];
			}

			// 3. PRÉCALCULS DE LIGNE (Exécutés 1 fois par ligne Y)
			// On calcule les offsets finaux pour cette ligne précise
			int lineScrollY = (int)(masterScrollY * bg->ScrollYRatio * scale) + (bg->OffsetY * scale);
			int lineScrollX = (int)(masterScrollX * bg->ScrollXRatio * scale) + (bg->OffsetX * scale);

			int rawY = hdY + lineScrollY;
			int pngY = rawY;

			// --- GESTION DU TILE Y ---
			if(!bg->TileY) {
				if(pngY < 0 || pngY >= bgHeight) continue;
			} else {
				pngY = rawY % bgHeight;
				if(pngY < 0) pngY += bgHeight;
			}

			// On pré-calcule les adresses de base pour éviter les multiplications dans la boucle X
			uint32_t pngBaseRowIndex = pngY * bgWidth;
			uint32_t outBaseRowIndex = hdY * hdWidth;



			// ==============================================================
			// LA FONCTION LAMBDA INLINÉE AVEC Z-BUFFER
			// ==============================================================
			auto blendPixel = [&](int localPngX, uint32_t localHdX) {
				uint32_t pixelColor = bg->Bitmap->PixelData[pngBaseRowIndex + localPngX];
				uint32_t alpha = (pixelColor >> 24);

				if(alpha > 0) {
					uint32_t outIdx = outBaseRowIndex + localHdX;

					// ===================================================
					// LE TEST DE PROFONDEUR (Z-TEST)
					// On dessine le background UNIQUEMENT s'il est devant (ou égal)
					// à l'élément qui se trouve actuellement à cet endroit de l'écran !
					// ===================================================
					if(bg->ZIndex >= _zBuffer[outIdx]) {

						if(alpha == 255) {
							// Opacité totale : On écrase
							out[outIdx] = pixelColor | 0xFF000000;
						} else {
							// Transparence : Alpha Blending 32-bits
							uint32_t dstColor = out[outIdx];
							uint32_t invAlpha = 255 - alpha;

							uint32_t s_RB = pixelColor & 0x00FF00FF;
							uint32_t s_AG = (pixelColor >> 8) & 0x00FF00FF;
							uint32_t d_RB = dstColor & 0x00FF00FF;
							uint32_t d_AG = (dstColor >> 8) & 0x00FF00FF;

							uint32_t out_RB = ((s_RB * alpha + d_RB * invAlpha) >> 8) & 0x00FF00FF;
							uint32_t out_AG = ((s_AG * alpha + d_AG * invAlpha) >> 8) & 0x00FF00FF;

							out[outIdx] = out_RB | (out_AG << 8) | 0xFF000000;
						}

						// OPTIONNEL MAIS RECOMMANDÉ : On met à jour le Z-Buffer !
						// Ainsi, si un 2ème <background> a un ZIndex de 60, il pourra se 
						// dessiner au-dessus de ce background (qui a par ex 50).
						_zBuffer[outIdx] = bg->ZIndex;
					}
				}
			};
			// ==============================================================
			// LES BOUCLES PRINCIPALES (Loop Unswitching & Modulo Removal)
			// ==============================================================

			// 2. OPTIMISATION : On sépare les deux logiques (Loop Unswitching)
			if(!bg->TileX) {

				// SCÉNARIO A : Pas de répétition (Image unique)
				for(uint32_t hdX = 0; hdX < hdWidth; hdX++) {
					int pngX = hdX + lineScrollX;
					if(pngX >= 0 && pngX < bgWidth) {
						blendPixel(pngX, hdX);
					}
				}

			} else {

				// SCÉNARIO B : Répétition infinie (TileX = true)
				// 1. OPTIMISATION : Calcul du point de départ SANS modulo dans la boucle
				int currentPngX = lineScrollX % bgWidth;
				if(currentPngX < 0) currentPngX += bgWidth;

				for(uint32_t hdX = 0; hdX < hdWidth; hdX++) {

					blendPixel(currentPngX, hdX);

					// Incrémentation basique : infiniment plus rapide qu'un modulo !
					currentPngX++;
					if(currentPngX >= bgWidth) {
						currentPngX = 0;
					}
				}
			}

		}
	}//backgrounds

	// ==========================================================
	// GESTION DES VIDÉOS (pl_mpeg) - LE RENDU FINAL
	// ==========================================================
	if(SnesHdPackLoader::ActivePack != nullptr && out != nullptr) {

		for(auto& video : SnesHdPackLoader::ActivePack->Videos) {
			if(!video->MatchesCondition()) continue;

			// 1. INITIALISATION (Lazy Loading)
			if(!video->IsPlaying && !video->HasPlayed) {
				std::string fullPath = FolderUtilities::CombinePath(SnesHdPackLoader::ActivePack->RootFolder, video->Filename);

				video->VideoPlayer = plm_create_with_filename(fullPath.c_str());
				if(video->VideoPlayer != nullptr) {
					video->VideoWidth = plm_get_width(video->VideoPlayer);
					video->VideoHeight = plm_get_height(video->VideoPlayer);

					if(video->VideoWidth <= 0 || video->VideoHeight <= 0) {
						plm_destroy(video->VideoPlayer);
						video->VideoPlayer = nullptr;
						video->HasPlayed = true;
						continue;
					}

					video->IsPlaying = true;
					video->TimeAccumulator = 0.0;
					plm_set_audio_enabled(video->VideoPlayer, !video->MuteAudio);

					// --- LE PONT AUDIO ---
					// On récupère le mixer directement depuis l'émulateur
					SoundMixer* mixer = _emu->GetSoundMixer();

					plm_set_audio_decode_callback(video->VideoPlayer, [](plm_t* mpeg, plm_samples_t* samples, void* user) {
						SoundMixer* audioMixer = static_cast<SoundMixer*>(user);
						if(audioMixer == nullptr) return;

						// La vidéo est stéréo (Gauche/Droite), donc 2 valeurs par "échantillon"
						int totalValues = samples->count * 2;
						std::vector<int16_t> intSamples(totalValues);

						// On convertit les 'float' de pl_mpeg en 'int16_t' pour Mesen
						for(int i = 0; i < totalValues; i++) {
							float f = samples->interleaved[i];

							// Sécurité : on limite la valeur pour éviter les distorsions/grésillements
							if(f > 1.0f) f = 1.0f;
							if(f < -1.0f) f = -1.0f;

							intSamples[i] = static_cast<int16_t>(f * 32767.0f);
						}

						// On récupère la fréquence de la vidéo (souvent 44100Hz ou 48000Hz)
						uint32_t sampleRate = plm_get_samplerate(mpeg);

						// On envoie le son converti à la carte son !
						audioMixer->PlayAudioBuffer(intSamples.data(), samples->count, sampleRate);

					}, mixer);
					// ----------------------


					video->CurrentFramePixels.resize(video->VideoWidth * video->VideoHeight * 4, 0);
				} else {
					video->HasPlayed = true;
					continue;
				}
			}

			// 2. LECTURE & SYNCHRONISATION
			if(video->IsPlaying && video->VideoPlayer != nullptr) {

				double fps = plm_get_framerate(video->VideoPlayer);
				if(fps <= 0.0) fps = 30.0;

				double frameTime = 1.0 / fps;
				video->TimeAccumulator += (1.0 / 60.0);

				bool newFrameDecoded = false;
				plm_frame_t* frame = nullptr;

				while(video->TimeAccumulator >= frameTime) {
					frame = plm_decode_video(video->VideoPlayer);
					video->TimeAccumulator -= frameTime;
					newFrameDecoded = true;
				}

				if(newFrameDecoded && frame != nullptr) {
					plm_frame_to_bgra(frame, video->CurrentFramePixels.data(), video->VideoWidth * 4);
				}

				if(plm_has_ended(video->VideoPlayer) && !video->Loop) {
					video->IsPlaying = false;
					video->HasPlayed = true;
					plm_destroy(video->VideoPlayer);
					video->VideoPlayer = nullptr;
					video->CurrentFramePixels.clear();
					continue;
				}

				// 3. DESSIN DES PIXELS SUR L'ÉCRAN 'out' !
				if(!video->CurrentFramePixels.empty()) {
					uint32_t* videoPixels = reinterpret_cast<uint32_t*>(video->CurrentFramePixels.data());

					// Les variables hdWidth, hdHeight et scale existent déjà dans ton code au-dessus !
					if(hdWidth > 0 && hdHeight > 0) {
						int startX = video->X;
						int startY = video->Y;
						int maxW = std::min(video->VideoWidth, (int)hdWidth - startX);
						int maxH = std::min(video->VideoHeight, (int)hdHeight - startY);

						if(maxW > 0 && maxH > 0) {
							for(int y = 0; y < maxH; y++) {
								for(int x = 0; x < maxW; x++) {
									int screenX = startX + x;
									int screenY = startY + y;



									if(screenX >= 0 && screenX < (int)hdWidth && screenY >= 0 && screenY < (int)hdHeight) {
										uint32_t pixel = videoPixels[y * video->VideoWidth + x];

										// On zappe le noir parfait de la vidéo
										if((pixel & 0x00FFFFFF) != 0) {

											uint32_t outIdx = screenY * outWidth + screenX;

											// ===================================================
											// LE TEST DE PROFONDEUR (Z-TEST) POUR LA VIDÉO
											// ===================================================
											if(video->ZIndex >= _zBuffer[outIdx]) {

												// La vidéo a le droit de dessiner !
												out[outIdx] = pixel | 0xFF000000;

												// On met à jour le Z-Buffer au cas où un élément
												// ayant un ZIndex encore plus élevé (ex: 99) voudrait
												// se dessiner par-dessus la vidéo plus tard !
												_zBuffer[outIdx] = video->ZIndex;
											}
										}
									}


								}
							}
						}
					}
				}
			}
		}
	}

	// ==========================================================
	// VERROUILLAGE FINAL DE L'ALPHA (Sécurité pour l'affichage)
	// ==========================================================
	// On s'assure que tous les pixels de l'écran final sont 100% opaques 
	// pour que la fenêtre de l'émulateur ne soit pas transparente.
	// ==========================================================
	if(out != nullptr && hdWidth > 0 && hdHeight > 0) {
		for(uint32_t y = 0; y < hdHeight; y++) {
			for(uint32_t x = 0; x < hdWidth; x++) {
				out[y * outWidth + x] |= 0xFF000000;
			}
		}
	}

}// end fonction ApplyFilter


//------------------------------------------------------------------------------------------------------------/


void SnesHdVideoFilter::ApplyFilterSpritesOAMScan(uint32_t scale, uint32_t outWidth, uint32_t outHeight, uint32_t* out)
{
	// 1. Sécurité
	if(!SnesHdPackLoader::ActivePack || !_emu) return;

	SnesConsole* console = (SnesConsole*)_emu->GetConsole().get();
	SnesPpu* ppu = console->GetPpu();
	if(!ppu) return;

	// 2. Récupération de la RAM des sprites brutes (OAM)
	uint8_t* oamRam = ppu->GetSpriteRam(); // 544 octets

	// --- LES PARAMÈTRES GLOBAUX DU PPU ---
	// La SNES permet de choisir deux tailles de sprites parmi une liste.
	// Ces valeurs sont dans le registre $2101 (OBSEL), on les simulera par des valeurs standards 
	// (8x8 et 16x16) pour le prototype, à affiner selon ton PPU.
	int smallSpriteSize = 8;
	int largeSpriteSize = 16;
	// -------------------------------------

	// 3. Boucle sur les 128 Sprites matériels
	for(int i = 0; i < 128; i++) {

		// --- LECTURE DU FORMAT OAM (544 Octets) ---
		// Les 512 premiers octets = 4 octets par sprite (X, Y, Char, Attr)
		uint32_t baseAddr = i * 4;

		// Les 32 derniers octets = La "Table Haute" (High Table) qui contient
		// le 9ème bit de X (pour les X négatifs ou > 255) et la taille du sprite.
		uint32_t highTableAddr = 512 + (i / 4);
		uint8_t highBits = (oamRam[highTableAddr] >> ((i % 4) * 2)) & 0x03;

		bool isLarge = (highBits & 0x02) != 0;
		int xBit9 = (highBits & 0x01) << 8;

		// --- EXTRACTION DES VALEURS ---
		int x = oamRam[baseAddr + 0] | xBit9;
		if(x > 255) x -= 512; // Gestion des nombres signés (hors-écran à gauche)

		int y = oamRam[baseAddr + 1];
		if(y == 240) continue; // Y=240 cache le sprite sur SNES
		if(y > 255) y -= 256;

		uint8_t tileIndex = oamRam[baseAddr + 2];
		uint8_t attributes = oamRam[baseAddr + 3];

		bool vFlip = (attributes & 0x80) != 0;
		bool hFlip = (attributes & 0x40) != 0;
		uint8_t priority = (attributes & 0x30) >> 4;
		uint8_t palette = (attributes & 0x0E) >> 1;
		bool nameTable = (attributes & 0x01) != 0; // Utilise la 2ème page de CHR RAM

		int size = isLarge ? largeSpriteSize : smallSpriteSize;

		// ====================================================================
		// LE TEST FATIDIQUE : CE SPRITE A-T-IL UN PNG HD ?
		// ====================================================================
		// On construit la clé de recherche. Le calcul du Hash dépend fortement 
		// de la façon dont 'MemoryHash' est généré dans ton loader pour les sprites.
		// En général, le Hash est (TileIndex | (NameTable << 8)).

		SnesHdTileKey key;
		key.MemoryHash = tileIndex | (nameTable ? 0x100 : 0x00);
		key.PaletteHash = 0; // Souvent 0 pour les sprites selon les packs
		key.Bpp = SnesBpp::Bpp4; // Les sprites sont toujours en 4BPP sur SNES
		key.IsLargeTile = isLarge;
		key.IsSprite = true;

		auto it = SnesHdPackLoader::ActivePack->TileByKey.find(key);
		if(it != SnesHdPackLoader::ActivePack->TileByKey.end() && !it->second.empty()) {

			// ON A TROUVÉ UN SPRITE HD !
			SnesHdPackTileInfo* hdTile = nullptr;

			// On cherche le bon PNG parmi les conditions
			for(auto* tile : it->second) {
				if(tile->MatchesCondition(x, y, nullptr)) {
					hdTile = tile;
					break;
				}
			}

			if(hdTile == nullptr || hdTile->HdTileData.empty()) continue;

			// ====================================================================
			// DESSIN DU SPRITE HD (SANS CLIPPING !)
			// ====================================================================
			// On calcule le Z-Index du sprite à partir de sa priorité matérielle
			uint8_t pixelZ = 20 + (priority * 4);

			uint32_t pngWidth = hdTile->Width * scale;
			uint32_t pngHeight = hdTile->Height * scale;

			// On dessine toute la surface du PNG !
			for(uint32_t py = 0; py < pngHeight; py++) {
				for(uint32_t px = 0; px < pngWidth; px++) {

					// Position finale sur l'écran HD
					int32_t screenX = (x * scale) + px;
					int32_t screenY = (y * scale) + py;

					// Culling : On ne dessine pas en dehors de l'écran final
					if(screenX < 0 || screenX >= (int32_t)outWidth || screenY < 0 || screenY >= (int32_t)outHeight) {
						continue;
					}

					// Lecture du pixel PNG avec gestion du Flip !
					uint32_t readX = hFlip ? (pngWidth - 1 - px) : px;
					uint32_t readY = vFlip ? (pngHeight - 1 - py) : py;

					uint32_t hdColorFromPng = hdTile->HdTileData[readY * pngWidth + readX];
					uint32_t alpha = (hdColorFromPng >> 24) & 0xFF;

					if(alpha > 0) {
						uint32_t pixelIndex = screenY * outWidth + screenX;

						// === LE Z-TEST ===
						// On ne dessine le sprite OAM que s'il est DEVANT ce qui est déjà dessiné.
						if(pixelZ >= _zBuffer[pixelIndex]) {

							// Opacité maximale (ou mixage si tu veux l'Alpha Blending complet ici)
							out[pixelIndex] = hdColorFromPng | 0xFF000000;

							// On met à jour le Z-Buffer
							_zBuffer[pixelIndex] = pixelZ;
						}
					}
				}
			}
		}
	}
}


//=====================================================================================================
void SnesHdVideoFilter::ApplyFilterSpritesStandard(uint32_t x, uint32_t y, uint32_t scale, uint32_t outWidth,
																	uint32_t sdColor, const SnesHdPixelData& hdData,
																	uint8_t pixelZ, uint32_t* out)
{
	// ===============================================
	// LA VOIE CLASSIQUE : SPRITES, TUILES TRADITIONNELLES
	// ===============================================
	for(uint32_t sy = 0; sy < scale; sy++) {
		for(uint32_t sx = 0; sx < scale; sx++) {

			uint32_t finalColor = sdColor;
			bool eraseThisTile = false;

			// 1. Règles globales d'effacement
			if(!hdData.IsSprite) {
				if(SnesHdPackLoader::ActivePack->DisableOriginalTiles) {
					eraseThisTile = true;
				} else {
					if(hdData.SourceLayer == 0 && SnesHdPackLoader::ActivePack->DisableBg1) eraseThisTile = true;
					else if(hdData.SourceLayer == 1 && SnesHdPackLoader::ActivePack->DisableBg2) eraseThisTile = true;
					else if(hdData.SourceLayer == 2 && SnesHdPackLoader::ActivePack->DisableBg3) eraseThisTile = true;
					else if(hdData.SourceLayer == 3 && SnesHdPackLoader::ActivePack->DisableBg4) eraseThisTile = true;
				}
			}

			// 2. Correction Zelda 3 Background
			if(hdData.Tile != nullptr && !hdData.Tile->HdTileData.empty()) {
				eraseThisTile = true;
			}

			if(eraseThisTile) {
				finalColor = 0x00000000;
			}

			// 3. Rendu HD
			if(hdData.Tile != nullptr && !hdData.Tile->HdTileData.empty()) {

				uint32_t baseTileX = hdData.IsSprite ? hdData.TileX : (7 - hdData.TileX);
				uint32_t baseTileY = hdData.TileY;

				uint32_t trueTileX = hdData.Tile->IsHFlip ? (7 - baseTileX) : baseTileX;
				uint32_t trueTileY = hdData.Tile->IsVFlip ? (7 - baseTileY) : baseTileY;

				bool doHFlip = hdData.HFlip && !hdData.Tile->IsHFlip;
				bool doVFlip = hdData.VFlip && !hdData.Tile->IsVFlip;

				uint32_t readSx = doHFlip ? (scale - 1 - sx) : sx;
				uint32_t readSy = doVFlip ? (scale - 1 - sy) : sy;

				uint32_t hdPixelX = (trueTileX * scale) + readSx;
				uint32_t hdPixelY = (trueTileY * scale) + readSy;
				uint32_t tileWidthHD = hdData.Tile->Width * scale;

				if((hdPixelY * tileWidthHD + hdPixelX) < hdData.Tile->HdTileData.size()) {
					uint32_t hdColorFromPng = hdData.Tile->HdTileData[hdPixelY * tileWidthHD + hdPixelX];

					if((hdColorFromPng >> 24) > 0) {
						if(SnesHdPackLoader::ActivePack->IsColorMathDisabled || hdData.Tile->IgnoreColorMath) {
							finalColor = hdColorFromPng;
						} else {
							uint32_t baseSdColor = _calculatedPalette[hdData.BaseColor];
							int diffR = ((sdColor >> 16) & 0xFF) - ((baseSdColor >> 16) & 0xFF);
							int diffG = ((sdColor >> 8) & 0xFF) - ((baseSdColor >> 8) & 0xFF);
							int diffB = (sdColor & 0xFF) - (baseSdColor & 0xFF);

							int outR = ((hdColorFromPng >> 16) & 0xFF) + diffR;
							int outG = ((hdColorFromPng >> 8) & 0xFF) + diffG;
							int outB = (hdColorFromPng & 0xFF) + diffB;

							outR = outR < 0 ? 0 : (outR > 255 ? 255 : outR);
							outG = outG < 0 ? 0 : (outG > 255 ? 255 : outG);
							outB = outB < 0 ? 0 : (outB > 255 ? 255 : outB);

							finalColor = (hdColorFromPng & 0xFF000000) | (outR << 16) | (outG << 8) | outB;
						}
					} else {
						if(!hdData.IsSprite) {
							finalColor = 0x00000000;
						} else {
							if(SnesHdPackLoader::ActivePack->DisableOriginalTiles) {
								finalColor = 0x00000000;
							} else {
								finalColor = _calculatedPalette[hdData.UnderlyingColor];
							}
						}
					}
				}
			}

			// 4. Écriture Pixel et Z-Buffer
			uint32_t pixelIndex = (y * scale + sy) * outWidth + (x * scale + sx);
			out[pixelIndex] = finalColor;
			_zBuffer[pixelIndex] = ((finalColor >> 24) == 0) ? 0 : pixelZ;
		}
	}
}

//--------------------------------------------------------------------------------------------


bool SnesHdPackTileAtPositionCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;

	SnesPpuState& state = _screenInfo->Ppu->GetStateRef();
	uint16_t* vram = (uint16_t*)_screenInfo->Ppu->GetVideoRam();
	if(!vram) return false;

	std::string logPath = "C:\\Users\\Gwen\\Documents\\Mesen2\\HdPacks\\TileDebug.Log";
	bool shouldLogThisFrame = (_screenInfo->FrameNumber == 60);
	std::ofstream* logfile = nullptr;

	if(shouldLogThisFrame) {
		logfile = new std::ofstream(logPath, std::ios_base::app);
		*logfile << "=== EVALUATION | Condition [" << Name << "] ===" << std::endl;
		*logfile << "Scope : " << (Scope == SnesHdPackConditionScope::Layer ? "LAYER" : "SCREEN") << std::endl;
		*logfile << "Cible Attendue : Tile=$" << HexUtilities::ToHex(this->MemoryHash) << " | Palette=" << this->PaletteHash << std::endl;
	}

	for(int layer = 0; layer < 4; layer++) {
		if((TargetLayers & (1 << layer)) == 0) continue;

		LayerConfig& config = state.Layers[layer];

		// Définition des limites de la boucle selon les Wildcards
		int startX = CheckAnyX ? 0 : this->TileX;
		int endX = CheckAnyX ? (Scope == SnesHdPackConditionScope::Layer ? (config.DoubleWidth ? 63 : 31) : 31) : this->TileX;

		int startY = CheckAnyY ? 0 : this->TileY;
		int endY = CheckAnyY ? (Scope == SnesHdPackConditionScope::Layer ? (config.DoubleHeight ? 63 : 31) : 31) : this->TileY;

		for(int ty = startY; ty <= endY; ty++) {
			for(int tx = startX; tx <= endX; tx++) {

				int tileCol, tileRow;

				// --- 1. CALCUL DES COORDONNÉES SELON LE SCOPE ---
				if(Scope == SnesHdPackConditionScope::Screen) {
					// Mode Écran : On convertit la tuile en pixels (tx * 8), on applique la caméra, et on repasse en tuile (/ 8)
					int mapX = ((tx * 8) + config.HScroll) & 0x3FF;
					int mapY = ((ty * 8) + config.VScroll) & 0x3FF;
					tileCol = mapX / 8;
					tileRow = mapY / 8;
				} else {
					// Mode Layer : On lit directement sur la carte brute (sans la caméra)
					tileCol = tx & (config.DoubleWidth ? 63 : 31);
					tileRow = ty & (config.DoubleHeight ? 63 : 31);
				}

				// --- 2. LOGIQUE VRAM SNES (Gestion des blocs 32x32) ---
				int finalCol = tileCol;
				int finalRow = tileRow;
				int mapOffset = 0;
				if(config.DoubleWidth && finalCol >= 32) { mapOffset += 32 * 32; finalCol -= 32; }
				if(config.DoubleHeight && finalRow >= 32) { mapOffset += (config.DoubleWidth ? 2 : 1) * 32 * 32; finalRow -= 32; }

				int vramIndex = config.TilemapAddress + mapOffset + (finalRow * 32) + finalCol;

				if(vramIndex >= 0x8000) continue; // Sécurité mémoire

				// --- 3. COMPARAISON ---
				uint16_t tileData = vram[vramIndex];
				uint16_t snesTileIndex = tileData & 0x03FF;
				uint32_t snesPalette = (tileData >> 10) & 0x07;

				bool isTileMatch = false;

				// --- LE TRI INTELLIGENT (Index ou Hash ?) ---
				if(this->MemoryHash <= 0xFFFF) {
					// CAS 1 : L'utilisateur a entré un Index VRAM (ex: 101)
					isTileMatch = (this->MemoryHash == snesTileIndex);
				} else {
					// CAS 2 : L'utilisateur a entré un Hash 64-bits (ex: 2FEE8E4AF5240326)

					// 1. On déduit le BPP exact en fonction du Mode BG de la SNES et du Calque
					uint32_t bpp = 2; // Valeur par défaut
					switch(state.BgMode) {
						case 0: bpp = 2; break;
						case 1: bpp = (layer < 2) ? 4 : 2; break;
						case 2: bpp = 4; break;
						case 3: bpp = (layer == 0) ? 8 : 4; break;
						case 4: bpp = (layer == 0) ? 8 : 2; break;
						case 5: bpp = (layer == 0) ? 4 : 2; break;
						case 6: bpp = 4; break;
						case 7: bpp = 8; break;
					}

					// 2. On calcule l'adresse en VRAM (ChrAddress dans Mesen)
					uint32_t tileStart = config.ChrAddress + (snesTileIndex * 4 * bpp);
					size_t wordCount = 4 * bpp;
					uint64_t actualTileHash = 0;

					// 3. On génère la signature 64-bits à la volée !
					for(size_t i = 0; i < wordCount; i++) {
						uint16_t word = vram[(tileStart + i) & 0x7FFF];
						actualTileHash = (actualTileHash * 31) + (word & 0xFF);
						actualTileHash = (actualTileHash * 31) + (word >> 8);
					}


					// MOUCHARD : Si l'émulateur croise la tuile 101, il écrit son vrai hash
					if(logfile && snesTileIndex == 101) {
						*logfile << "=> INFO : Hash reel calcule pour la tuile 101 = $" << HexUtilities::ToHex(actualTileHash) << std::endl;
					}
					isTileMatch = (this->MemoryHash == actualTileHash);
				}

				// --- VÉRIFICATION FINALE ---
				if(isTileMatch) {
					if(this->IgnorePalette || this->PaletteHash == snesPalette) {
						// VICTOIRE !
						if(logfile) {
							*logfile << "======> MATCH PARFAIT SUR LAYER " << (layer + 1)
								<< " | Trouvé à X:" << tx << " Y:" << ty << " <======" << std::endl;
							logfile->close(); delete logfile;
						}
						return true;
					}
				}

				/*
				// --- 3. COMPARAISON ---
				uint16_t tileData = vram[vramIndex];
				uint16_t snesTileIndex = tileData & 0x03FF;
				uint32_t snesPalette = (tileData >> 10) & 0x07;

				if(this->MemoryHash == snesTileIndex) {
					if(this->IgnorePalette || this->PaletteHash == snesPalette) {
						// VICTOIRE !
						if(logfile) {
							*logfile << "======> MATCH PARFAIT SUR LAYER " << (layer + 1)
								<< " | Trouvé à X:" << tx << " Y:" << ty << " <======" << std::endl;
							logfile->close(); delete logfile;
						}
						return true;
					}
				}//3
				*/


			}
		}
	}

	if(logfile) {
		*logfile << "=> ECHEC : Aucune tuile correspondante trouvée." << std::endl;
		logfile->close(); delete logfile;
	}

	return false;
}



//--------------------------------------------------------------------------------------------------
/*bool SnesHdPackSpriteAtPositionCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;
	uint8_t* oamRam = _screenInfo->Ppu->GetSpriteRam();
	if(!oamRam) return false;

	for(int i = 0; i < 128; i++) {
		int offset = i * 4;
		uint8_t spriteX = oamRam[offset + 0];
		uint8_t spriteY = oamRam[offset + 1];

		if(spriteX == this->TileX && spriteY == this->TileY) {
			return true;
		}
	}
	return false;
}*/

bool SnesHdPackSpriteAtPositionCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;

	uint8_t* oamRam = _screenInfo->Ppu->GetSpriteRam();
	uint16_t* vram = (uint16_t*)_screenInfo->Ppu->GetVideoRam();
	if(!oamRam || !vram) return false;

	SnesPpuState& state = _screenInfo->Ppu->GetStateRef();

	for(int i = 0; i < 128; i++) {
		int offset = i * 4;

		// 1. Lecture des coordonnées
		uint8_t spriteX = oamRam[offset + 0];
		uint8_t spriteY = oamRam[offset + 1];

		// On vérifie d'abord si on est à la bonne position
		if(spriteX == this->TileX && spriteY == this->TileY) {

			// 2. Extraction de l'Index et de la Palette depuis l'OAM de la SNES
			// Byte 2 = les 8 premiers bits de l'index
			// Byte 3 = le 9ème bit de l'index (bit 0) et la palette (bits 1 à 3)
			uint16_t snesTileIndex = oamRam[offset + 2] | ((oamRam[offset + 3] & 0x01) << 8);
			uint32_t snesPalette = (oamRam[offset + 3] >> 1) & 0x07;

			bool isTileMatch = false;

			// --- LE TRI INTELLIGENT (Index ou Hash ?) ---
			if(this->MemoryHash <= 0xFFFF) {
				// CAS 1 : Index VRAM (ex: 101)
				isTileMatch = (this->MemoryHash == snesTileIndex);
			} else {
				// CAS 2 : Hash 64-bits
								// Sur SNES, les sprites (OBJ) sont TOUJOURS en 4 BPP.
				uint32_t bpp = 4;

				// --- CALCUL DE L'ADRESSE VRAM DU SPRITE ---
				uint32_t tileAddress = state.OamBaseAddress;
				if(snesTileIndex >= 256) {
					// Si le sprite utilise la 2ème page de tuiles, on ajoute l'offset
					tileAddress += state.OamAddressOffset;
				}

				// On calcule le point de départ en VRAM (modulo 256 car on a géré la page au-dessus)
				uint32_t tileStart = tileAddress + ((snesTileIndex % 256) * 4 * bpp);
				size_t wordCount = 4 * bpp;
				uint64_t actualTileHash = 0;

				for(size_t j = 0; j < wordCount; j++) {
					uint16_t word = vram[(tileStart + j) & 0x7FFF];
					actualTileHash = (actualTileHash * 31) + (word & 0xFF);
					actualTileHash = (actualTileHash * 31) + (word >> 8);
				}

				isTileMatch = (this->MemoryHash == actualTileHash);
			}

			// --- VÉRIFICATION FINALE ---
			if(isTileMatch) {
				if(this->IgnorePalette || this->PaletteHash == snesPalette) {
					return true; // Match parfait du sprite !
				}
			}
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------
bool SnesHdPackTileNearbyCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;

	SnesPpuState& state = _screenInfo->Ppu->GetStateRef();
	uint16_t* vram = (uint16_t*)_screenInfo->Ppu->GetVideoRam();
	if(!vram) return false;

	// Calcul des limites de recherche (en pixels écran)
	// Si le Joker '*' est actif, on scanne tout l'écran (0 à 255/239). Sinon, on cible le pixel précis.
	int startX = CheckAnyX ? 0 : (x + OffsetX);
	int endX = CheckAnyX ? 255 : startX;
	int stepX = CheckAnyX ? 8 : 1; // On avance de tuile en tuile si on scanne tout l'écran

	int startY = CheckAnyY ? 0 : (y + OffsetY);
	int endY = CheckAnyY ? 239 : startY; // La SNES affiche généralement jusqu'à 240 pixels en hauteur
	int stepY = CheckAnyY ? 8 : 1;

	// On cherche sur toutes les layers (plans de décor)
	for(int layer = 0; layer < 4; layer++) {
		LayerConfig& config = state.Layers[layer];

		for(int py = startY; py <= endY; py += stepY) {
			for(int px = startX; px <= endX; px += stepX) {

				// 1. Conversion du pixel écran en coordonnée de tuile (avec gestion de la caméra / Scroll)
				// Le & 0x3FF (1023) permet de gérer parfaitement les coordonnées négatives (wrap-around)
				int mapX = (px + config.HScroll) & 0x3FF;
				int mapY = (py + config.VScroll) & 0x3FF;
				int tileCol = mapX / 8;
				int tileRow = mapY / 8;

				// 2. Logique VRAM SNES (Gestion des blocs 32x32 de la Tilemap)
				int finalCol = tileCol;
				int finalRow = tileRow;
				int mapOffset = 0;

				if(config.DoubleWidth && finalCol >= 32) { mapOffset += 32 * 32; finalCol -= 32; }
				if(config.DoubleHeight && finalRow >= 32) { mapOffset += (config.DoubleWidth ? 2 : 1) * 32 * 32; finalRow -= 32; }

				int vramIndex = config.TilemapAddress + mapOffset + (finalRow * 32) + finalCol;
				if(vramIndex >= 0x8000) continue; // Sécurité

				// 3. Lecture et Comparaison
				/*
				uint16_t tileData = vram[vramIndex];
				uint16_t snesTileIndex = tileData & 0x03FF;
				uint32_t snesPalette = (tileData >> 10) & 0x07;

				if(this->MemoryHash == snesTileIndex) {
					if(this->IgnorePalette || this->PaletteHash == snesPalette) {
						return true; // Match Parfait !
					}
				}
				*/

				// 3. Lecture et Comparaison
				uint16_t tileData = vram[vramIndex];
				uint16_t snesTileIndex = tileData & 0x03FF;
				uint32_t snesPalette = (tileData >> 10) & 0x07;

				bool isTileMatch = false;

				// --- LE TRI INTELLIGENT (Index ou Hash ?) ---
				if(this->MemoryHash <= 0xFFFF) {
					// CAS 1 : Index VRAM
					isTileMatch = (this->MemoryHash == snesTileIndex);
				} else {
					// CAS 2 : Hash 64-bits (Live)
					uint32_t bpp = 2;
					switch(state.BgMode) {
						case 0: bpp = 2; break;
						case 1: bpp = (layer < 2) ? 4 : 2; break;
						case 2: bpp = 4; break;
						case 3: bpp = (layer == 0) ? 8 : 4; break;
						case 4: bpp = (layer == 0) ? 8 : 2; break;
						case 5: bpp = (layer == 0) ? 4 : 2; break;
						case 6: bpp = 4; break;
						case 7: bpp = 8; break;
					}

					uint32_t tileStart = config.ChrAddress + (snesTileIndex * 4 * bpp);
					size_t wordCount = 4 * bpp;
					uint64_t actualTileHash = 0;

					for(size_t j = 0; j < wordCount; j++) {
						uint16_t word = vram[(tileStart + j) & 0x7FFF];
						actualTileHash = (actualTileHash * 31) + (word & 0xFF);
						actualTileHash = (actualTileHash * 31) + (word >> 8);
					}

					isTileMatch = (this->MemoryHash == actualTileHash);
				}

				// --- VÉRIFICATION FINALE ---
				if(isTileMatch) {
					if(this->IgnorePalette || this->PaletteHash == snesPalette) {
						return true; // Match Parfait !
					}
				}



			}
		}
	}

	return false;
}
//--------------------------------------------------------------------------------------------------
/*bool SnesHdPackSpriteNearbyCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;

	uint8_t* oam = _screenInfo->Ppu->GetSpriteRam();
	if(!oam) return false;

	// Tables de taille de sprites de Mesen
	static constexpr uint8_t oamWidth[16] = { 8, 8, 8, 16, 16, 32, 16, 16, 16, 32, 64, 32, 64, 64, 32, 32 };
	static constexpr uint8_t oamHeight[16] = { 8, 8, 8, 16, 16, 32, 32, 32, 16, 32, 64, 32, 64, 64, 64, 32 };
	static constexpr uint16_t sign[2] = { 0x0000, 0xFF00 };

	int targetX = CheckAnyX ? -1 : (x + OffsetX);
	int targetY = CheckAnyY ? -1 : (y + OffsetY);

	SnesPpuState& state = _screenInfo->Ppu->GetStateRef();

	// On boucle sur les 128 Sprites
	for(uint8_t i = 0; i < 128; i++) {

		// 1. Calcul de la position (X, Y) et des dimensions
		uint8_t highTableValue = oam[0x200 | (i >> 2)] >> ((i << 1) & 0x06);
		int16_t spriteX = (int16_t)(sign[highTableValue & 0x01] | oam[(i << 2)]);
		uint8_t spriteY = oam[(i << 2) + 1];

		// Si le sprite est hors écran, on l'ignore
		if(spriteY >= 240 && spriteY != 255) continue;

		uint8_t mode = state.OamMode | ((highTableValue & 0x02) << 2);
		int sprWidth = oamWidth[mode];
		int sprHeight = oamHeight[mode];

		// 2. Vérification des coordonnées
		bool matchX = CheckAnyX || (targetX >= spriteX && targetX < (spriteX + sprWidth));
		bool matchY = CheckAnyY || (targetY >= spriteY && targetY < (spriteY + sprHeight));

		if(matchX && matchY) {

			// 3. Extraction du TileIndex et de la Palette
			uint16_t oamAddress = (i << 2);
			uint8_t flags = oam[oamAddress + 1];
			uint8_t paletteIndex = (flags >> 1) & 0x07;

			uint8_t tileRow = (oam[oamAddress] & 0xF0) >> 4;
			uint8_t tileColumn = oam[oamAddress] & 0x0F;
			uint16_t tileIndex = (tileRow << 4) | tileColumn;
			// (Note: Pour être ultra précis sur des sprites 16x16 ou 32x32,
			// on check ici le Hash de la tuile principale (haut-gauche) du sprite).

			if(this->MemoryHash == tileIndex) {
				if(this->IgnorePalette || this->PaletteHash == (uint32_t)(paletteIndex + 8)) {
					return true; // Match Parfait !
				}
			}
		}
	}

	return false;
}
*/
bool SnesHdPackSpriteNearbyCondition::InternalCheckCondition(int x, int y, SnesHdPixelData* tile)
{
	if(!_screenInfo || !_screenInfo->Ppu) return false;

	uint8_t* oamRam = _screenInfo->Ppu->GetSpriteRam();
	uint16_t* vram = (uint16_t*)_screenInfo->Ppu->GetVideoRam();
	if(!oamRam || !vram) return false;

	// Tables de taille de sprites de Mesen
	static constexpr uint8_t oamWidth[16] = { 8, 8, 8, 16, 16, 32, 16, 16, 16, 32, 64, 32, 64, 64, 32, 32 };
	static constexpr uint8_t oamHeight[16] = { 8, 8, 8, 16, 16, 32, 32, 32, 16, 32, 64, 32, 64, 64, 64, 32 };
	static constexpr uint16_t sign[2] = { 0x0000, 0xFF00 };

	int targetX = CheckAnyX ? -1 : (x + OffsetX);
	int targetY = CheckAnyY ? -1 : (y + OffsetY);

	SnesPpuState& state = _screenInfo->Ppu->GetStateRef();

	// On boucle sur les 128 Sprites
	for(uint8_t i = 0; i < 128; i++) {

		int offset = i * 4;

		// 1. Calcul de la position (X, Y) et des dimensions
		uint8_t highTableValue = oamRam[0x200 | (i >> 2)] >> ((i << 1) & 0x06);
		int16_t spriteX = (int16_t)(sign[highTableValue & 0x01] | oamRam[offset + 0]);
		uint8_t spriteY = oamRam[offset + 1];

		// Si le sprite est hors écran, on l'ignore (240 pixels max sur SNES)
		if(spriteY >= 240 && spriteY != 255) continue;

		uint8_t mode = state.OamMode | ((highTableValue & 0x02) << 2);
		int sprWidth = oamWidth[mode];
		int sprHeight = oamHeight[mode];

		// 2. Vérification de la hitbox (Est-ce que le pixel cible touche ce sprite ?)
		bool matchX = CheckAnyX || (targetX >= spriteX && targetX < (spriteX + sprWidth));
		bool matchY = CheckAnyY || (targetY >= spriteY && targetY < (spriteY + sprHeight));

		if(matchX && matchY) {

			// 3. Extraction de l'Index et de la Palette (comme pour SpriteAtPosition)
			uint16_t snesTileIndex = oamRam[offset + 2] | ((oamRam[offset + 3] & 0x01) << 8);
			uint32_t snesPalette = (oamRam[offset + 3] >> 1) & 0x07;

			bool isTileMatch = false;

			// --- LE TRI INTELLIGENT (Index ou Hash ?) ---
			if(this->MemoryHash <= 0xFFFF) {
				// CAS 1 : Index VRAM
				isTileMatch = (this->MemoryHash == snesTileIndex);
			} else {
				// CAS 2 : Hash 64-bits
				uint32_t bpp = 4;

				uint32_t tileAddress = state.OamBaseAddress;
				if(snesTileIndex >= 256) {
					tileAddress += state.OamAddressOffset;
				}

				uint32_t tileStart = tileAddress + ((snesTileIndex % 256) * 4 * bpp);
				size_t wordCount = 4 * bpp;
				uint64_t actualTileHash = 0;

				for(size_t j = 0; j < wordCount; j++) {
					uint16_t word = vram[(tileStart + j) & 0x7FFF];
					actualTileHash = (actualTileHash * 31) + (word & 0xFF);
					actualTileHash = (actualTileHash * 31) + (word >> 8);
				}

				isTileMatch = (this->MemoryHash == actualTileHash);
			}

			// --- VÉRIFICATION FINALE ---
			if(isTileMatch) {
				// Note : Dans l'OAM, les palettes vont de 0 à 7 (visuellement 8 à 15). 
				// Ton ancien code ajoutait +8, on l'a enlevé ici car SnesPalette est déjà entre 0 et 7.
				if(this->IgnorePalette || this->PaletteHash == snesPalette) {
					return true; // Match Parfait !
				}
			}
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------
OverscanDimensions SnesHdVideoFilter::GetOverscan()
{
	// Si un pack HD est actif et qu'il possède le tag <overscan>
	if(SnesHdPackLoader::ActivePack != nullptr && SnesHdPackLoader::ActivePack->HasOverscanConfig) {
		return SnesHdPackLoader::ActivePack->Overscan;
	} else {
		// Sinon, on appelle gentiment l'overscan standard de la console parent
		return SnesDefaultVideoFilter::GetOverscan();
	}
}
//--------------------------------------------------------------------------------------------------